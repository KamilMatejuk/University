package com.example.l5z1.game

import android.graphics.RectF


class Player(screenX: Int, screenY: Int) {
    val length = 200f
    val height = 30f
    val rect = RectF(
        (screenX - length) / 2,
        screenY - height,
        (screenX + length) / 2,
        screenY.toFloat()
    )
    private val speed = 350f

    // Which ways can the paddle move
    val STOPPED = 0
    val LEFT = 1
    val RIGHT = 2
    private var paddleMoving = STOPPED

    fun setMovementState(state: Int) {
        paddleMoving = state
    }

    fun update(fps: Long) {
        if (paddleMoving == LEFT) {
            rect.left -= speed / fps
            rect.right = rect.left + length
        }
        if (paddleMoving == RIGHT) {
            rect.left += speed / fps
            rect.right = rect.left + length
        }
    }
}