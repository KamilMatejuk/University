package com.example.l5z1.game

import android.app.Activity
import android.content.Context
import android.content.Context.WINDOW_SERVICE
import android.graphics.*
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.l5z1.R


internal class GameView(context: Context, cellsStr: String) : SurfaceView(context), Runnable {
    var gameThread: Thread? = null
    var ourHolder: SurfaceHolder = holder
    var playing = false
    var paused = true
    var fps: Long = 0
    private var timeThisFrame: Long = 0

    var screenX: Int
    var screenY: Int

    var player: Player
    var ball: Ball
    private var cells: ArrayList<Cell>

    init {
        val displayMetrics = DisplayMetrics()
        val windowsManager = context.getSystemService(WINDOW_SERVICE) as WindowManager
        windowsManager.defaultDisplay.getMetrics(displayMetrics)
        screenX = displayMetrics.widthPixels
        screenY = displayMetrics.heightPixels

        player = Player(screenX, screenY)
        ball = Ball(screenX, screenY)
        ball.setRandomXVelocity()

        val out = TypedValue()
        context.resources.getValue(R.dimen.number_of_columns, out, true)
        val columns = out.float.toInt()
        val brickWidth = screenX / columns
        val brickHeight = 70
        cells = arrayListOf()
        println(cells)
        for (cell in cellsStr.split("|")) {
            val trimmed = cell.trim().split(" ")
            if (trimmed.size == 2) {
                val i = cell.trim().split(" ")[0].toInt()
                val j = cell.trim().split(" ")[1].toInt()
                cells.add(Cell(i, j, brickWidth, brickHeight))
            }
        }
    }

    override fun run() {
        while (playing) {
            val startFrameTime = System.currentTimeMillis()
            if (!paused) {
                update()
            }
            draw()
            timeThisFrame = System.currentTimeMillis() - startFrameTime
            if (timeThisFrame >= 1) {
                fps = 1000 / timeThisFrame
            }
        }
    }

    fun update() {
        player.update(fps)
        ball.update(fps)

        // Check for ball colliding with a cell
        var index: Int = -1
        for (cell in cells) {
            if(RectF.intersects(cell.rect, ball.rect)) {
                index = cells.indexOf(cell)
                ball.yVelocity = -ball.yVelocity
            }
        }
        if (index != -1) {
            DataIO.editLast(cells[index].row, cells[index].column)
            cells.removeAt(index)
        }

        if (ball.rect.bottom > screenY - player.height) {
            if (ball.rect.right >= player.rect.left && ball.rect.left <= player.rect.right) {
                // Ball colliding with player
                ball.yVelocity = -ball.yVelocity
            } else {
                // Ball outside of screen
                ContextCompat.getMainExecutor(context).execute {
                    Toast.makeText(context, "You lose", Toast.LENGTH_SHORT).show()
                    (context as Activity).finish()
                }
            }
        }

        // Bounce the ball back when it hits the top of screen
        if (ball.rect.top < 0) {
            ball.yVelocity = -ball.yVelocity
        }

        // If the ball hits left wall bounce
        if (ball.rect.left < 0) {
            ball.xVelocity = -ball.xVelocity
        }

        // If the ball hits right wall bounce
        if (ball.rect.right > screenX - ball.size) {
            ball.xVelocity = -ball.xVelocity
        }

        // Finish if cleared screen
        if (cells.size == 0) {
            ContextCompat.getMainExecutor(context).execute {
                Toast.makeText(context, "You won", Toast.LENGTH_SHORT).show()
                (context as Activity).finish()
            }
            DataIO.deleteLast()
        }
    }

    // Draw the newly updated scene
    fun draw() {
        if (ourHolder.surface.isValid) {
            val canvas = ourHolder.lockCanvas()
            val paint = Paint()

            // Draw the background color
            canvas.drawColor(resources.getColor(R.color.black))
            paint.color = resources.getColor(R.color.white)

            // player
            canvas.drawRect(player.rect, paint)

            // ball
            canvas.drawRect(ball.rect, paint)

            // cells
            paint.color = resources.getColor(R.color.cell_color)
            for (cell in cells) {
                canvas.drawRect(cell.rect, paint)
            }

            // Draw everything to the screen
            ourHolder.unlockCanvasAndPost(canvas)
        }
    }

    fun pause() {
        playing = false
        try {
            gameThread!!.join()
        } catch (e: InterruptedException) {
            Log.e("Error:", "joining thread")
        }
    }

    fun resume() {
        playing = true
        gameThread = Thread(this)
        gameThread!!.start()
    }

    override fun onTouchEvent(motionEvent: MotionEvent): Boolean {
        when (motionEvent.action and MotionEvent.ACTION_MASK) {
            MotionEvent.ACTION_DOWN -> {
                paused = false
                if (motionEvent.x > screenX / 2) {
                    player.setMovementState(player.RIGHT)
                } else {
                    player.setMovementState(player.LEFT)
                }
            }
            MotionEvent.ACTION_UP -> player.setMovementState(player.STOPPED)
        }
        return true
    }
}