package com.example.l5z1.game

import android.content.Context
import android.os.Parcelable
import android.util.TypedValue
import androidx.room.*
import kotlinx.android.parcel.Parcelize
import com.example.l5z1.R


@Entity
@Parcelize
data class GameData(
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    @ColumnInfo(name = "cells") var cells: String
) : Parcelable


/**
 * Database access object with defined queries
 */
@Dao
interface GameDAO {
    @Query("SELECT * FROM GameData ORDER BY id DESC LIMIT 1")
    fun getLast(): List<GameData>

    @Insert
    fun insert(item: GameData)

    @Delete
    fun delete(item: GameData)

    @Query("DELETE FROM GameData")
    fun clear()
}

/**
 * Datbase storing all GameDatas
 */
@Database(entities = [GameData::class], version = 2)
abstract class AppDatabase : RoomDatabase() {
    abstract fun GameDao(): GameDAO
}

/**
 * Singleton object used for connection, between app and database
 */
object DataIO {
    private lateinit var db: GameDAO

    /**
     * Create database instance at the beginning of app lifecycle
     */
    fun initializeDatabase(context: Context) {
        db = Room.databaseBuilder(
            context,
            AppDatabase::class.java, "l5z1-database"
        ).build().GameDao()
    }

    /**
     * Getter
     */
    fun getLast(): GameData? {
        val list = db.getLast()
        return if (list.isNotEmpty()) {
            list[0]
        } else {
            null
        }
    }

    /**
     * Operations on values
     */
    fun createGame(context: Context) {
        val out = TypedValue()
        context.resources.getValue(R.dimen.number_of_columns, out, true)
        val columns = out.float.toInt()
        context.resources.getValue(R.dimen.number_of_rows, out, true)
        val rows = out.float.toInt()

        var cells = ""
        for (i in 0 until rows) {
            for (j in 0 until columns) {
                cells += "$i $j | "
            }
        }
        this.db.insert(GameData(cells = cells))
    }

    fun editLast(cellX: Int, cellY: Int) {
        val items = this.db.getLast()
        if (items.isNotEmpty()) {
            val cells = items[0].cells.replace("$cellX $cellY", "")
            this.db.insert(
                GameData(
                    cells = cells,
                )
            )
        }
    }

    fun deleteLast() {
        val items = this.db.getLast()
        if (items.isNotEmpty()) {
            this.db.delete(items[0])
        }
    }

}