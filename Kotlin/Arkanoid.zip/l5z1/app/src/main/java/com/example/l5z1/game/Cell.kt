package com.example.l5z1.game

import android.graphics.RectF


class Cell(val row: Int, val column: Int, width: Int, height: Int) {
    private val padding = 3
    val rect = RectF(
        (column * width + padding).toFloat(),
        (row * height + padding).toFloat(),
        (column * width + width - padding).toFloat(),
        (row * height + height - padding).toFloat()
    )
}