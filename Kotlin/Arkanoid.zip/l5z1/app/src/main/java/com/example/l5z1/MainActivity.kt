package com.example.l5z1

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.l5z1.game.DataIO

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Thread {
            DataIO.initializeDatabase(this)
        }.start()
    }

    fun startNew(view: View) {
        Thread {
            DataIO.createGame(this)
            val items = DataIO.getLast()
            if (items != null) {
                val intent = Intent(this, GameActivity::class.java)
                intent.putExtra("cells", items.cells)
                startActivity(intent)
            }
        }.start()
    }

    fun loadPrevious(view: View) {
        Thread {
            val items = DataIO.getLast()
            if (items == null) {
                ContextCompat.getMainExecutor(this).execute {
                    Toast.makeText(this, "There is no game saved", Toast.LENGTH_SHORT).show()
                }
            } else {
                val intent = Intent(this, GameActivity::class.java)
                intent.putExtra("cells", items.cells)
                startActivity(intent)
            }
        }.start()

    }

}