package com.example.l5z1

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.l5z1.game.GameView


class GameActivity : AppCompatActivity() {
    private lateinit var GameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cells = intent.getStringExtra("cells")
        if (cells == null) {
            Toast.makeText(this, "Error reading data from memmory", Toast.LENGTH_SHORT).show()
        } else {
            GameView = GameView(this, cells)
            setContentView(GameView)
        }
    }

    // This method executes when the player starts the game
    override fun onResume() {
        super.onResume()
        // Tell the gameView resume method to execute
        GameView.resume()
    }

    // This method executes when the player quits the game
    override fun onPause() {
        super.onPause()
        // Tell the gameView pause method to execute
        GameView.pause()
    }
}