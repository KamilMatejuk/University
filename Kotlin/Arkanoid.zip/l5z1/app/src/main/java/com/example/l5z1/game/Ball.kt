package com.example.l5z1.game

import android.graphics.RectF
import kotlin.random.Random


class Ball(screenX: Int, screenY: Int) {
    var xVelocity = 300f
    var yVelocity = -500f
    var size = 25f
    val rect = RectF(
        (screenX - size) / 2,
        (screenY - size) / 2,
        (screenX + size) / 2,
        (screenY + size) / 2
    )

    fun update(fps: Long) {
        rect.left = rect.left + xVelocity / fps
        rect.top = rect.top + yVelocity / fps
        rect.right = rect.left + size
        rect.bottom = rect.top - size
    }

    fun setRandomXVelocity() {
        if (Random.nextInt(2) == 0){
            xVelocity = -xVelocity
        }
    }
}