package com.example.l6z1

data class Option(
    val name: String,
    val path: String,
    val hint: String,
    val example: String
)

object Options {
    var options = arrayListOf<Option>()

    init {
        options.add(Option("Simplify", "simplify", "<equation>", "2^2+2(2)"))
        options.add(Option("Factor", "factor", "<equation>", "x^2 + 2x"))
        options.add(Option("Derive", "derive", "<equation>", "x^2+2x"))
        options.add(Option("Integrate", "integrate", "<equation>", "x^2+2x"))
        options.add(Option("Find 0's", "zeroes", "<equation>", "x^2+2x"))
        options.add(Option("Find Tangent", "tangent", "<point> | <equation>", "2|x^3"))
        options.add(Option("Area Under Curve", "area", "<start-boundry> : <end-boundry> | <equation>", "2:4|x^3"))
        options.add(Option("Cosine", "cos", "<value>", "pi"))
        options.add(Option("Sine", "sin", "<value>", "0"))
        options.add(Option("Tangent", "tan", "<value>", "0"))
        options.add(Option("Inverse Cosine", "arccos", "<value>", "1"))
        options.add(Option("Inverse Sine", "arcsin", "<value>", "0"))
        options.add(Option("Inverse Tangent", "arctan", "<value>", "0"))
        options.add(Option("Absolute Value", "abs", "<value>", "-1"))
        options.add(Option("Logarithm", "log", "<base> | <value>", "2|8"))
    }

    fun getAllOptions(): List<String> {
        return options.map { o -> o.name }
    }

    fun getOptionByName(name: String): Option? {
        for (o in options) {
            if (o.name == name) {
                return o
            }
        }
        return null
    }
}