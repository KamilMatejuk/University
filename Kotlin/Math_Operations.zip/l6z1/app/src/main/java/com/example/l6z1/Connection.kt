package com.example.l6z1

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.GET
import retrofit2.http.Path

object Connection {
    private lateinit var service: NewtonApiService
    init {
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("https://newton.now.sh/api/v2/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        service = retrofit.create(NewtonApiService::class.java)
    }

    fun send(context: Context, operation: String?, expression: String?, setText: (String) -> Unit) {
        val exp = expression?.replace("+", "%2b")
        val call: Call<JsonObject>? = service.send(operation, exp)
        println("request url ${call?.request()?.url()}")

        call!!.enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>?, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()?.get("result").toString()
                    setText(result)
                } else {
                    var result = response.errorBody()?.string() ?: "Error"
                    val msg = result.split("\"")
                    result = if (msg.size >= 4) {
                        msg[3]
                    } else {
                        msg[0]
                    }
                    setText(result)
                }
            }

            override fun onFailure(call: Call<JsonObject?>?, t: Throwable) {
                val text = t.toString()
                println(text)
                Toast
                    .makeText(context, text, Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }

    fun checkPermissions(context: Context) {
        if (ContextCompat.checkSelfPermission(
                context.applicationContext,
                Manifest.permission.INTERNET
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                context as Activity,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                1
            )
        } else {
            Toast.makeText(context, "Internet permissions granted", Toast.LENGTH_SHORT).show()
        }
    }
}

interface NewtonApiService {
    @GET("{operation}/{expression}/")
    fun send(
        @Path("operation", encoded = true) operation: String?,
        @Path("expression", encoded = true) expression: String?
    ): Call<JsonObject>?
}