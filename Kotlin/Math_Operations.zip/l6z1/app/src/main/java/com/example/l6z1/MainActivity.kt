package com.example.l6z1

import android.os.Bundle
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemSelectedListener
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var expression: EditText
    private lateinit var result: TextView
    private lateinit var hint: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinner = findViewById(R.id.options_spinner)
        expression = findViewById(R.id.expression)
        result = findViewById(R.id.result)
        hint = findViewById(R.id.hint)

        val allOptions = Options.getAllOptions()

        // load data into spinner
        ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            allOptions
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
            val option = Options.getOptionByName(allOptions[0])
            hint.text = "${option?.hint}\n${option?.example}"
        }

        // set on change listener
        spinner.onItemSelectedListener = object : OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>?,
                selectedItemView: View,
                position: Int,
                id: Long
            ) {
                val option = Options.getOptionByName(allOptions[position])
                hint.text = "${option?.hint}\n${option?.example}"
            }

            override fun onNothingSelected(parentView: AdapterView<*>?) {}
        }

        // check internet permissions
        Connection.checkPermissions(this)
    }

    fun calculate(view: View) {
        findViewById<TextView>(R.id.result).text = "..."
        // selected option
        val selected = spinner.selectedItem.toString()
        val option = Options.getOptionByName(selected)
        val path = option?.path
        // input expression
        val exp = this.expression.text.toString().trim()
        if (exp.isEmpty()) {
            return
        }
        Connection.send(applicationContext, path, exp,
            setText = { result ->
                run {
                    this.result.text = result.replace("\"", "")
                }
            })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.run {
            putInt("operation", spinner.selectedItemPosition)
            putString("expression", expression.text.toString())
            putString("result", result.text.toString())
        }
        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        with (savedInstanceState) {
            val operation = getInt("operation")
            spinner.setSelection(operation)
            val exp = getString("expression")
            expression.setText(exp)
            val res = getString("result")
            result.text = res
        }
    }
}