package com.example.l3z4

import android.content.Intent
import android.os.Bundle
import android.util.DisplayMetrics
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager
import com.example.l3z4.tools.Notification
import com.example.l3z4.tools.Theme
import com.example.l3z4.databinding.ActivityLoadingBinding
import com.example.l3z4.tools.DataIO


class LoadingActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoadingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // set theme
        Theme.setTheme(this, R.style.Theme_L3z1_Dark_NoActionBar, R.style.Theme_L3z1_Light_NoActionBar)

        // create view
        binding = ActivityLoadingBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // set progress bar width
        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        val width = displayMetrics.widthPixels
        binding.progressBar.layoutParams.width = (width * 0.7).toInt()

        // create database
        var created = false
        Thread {
            DataIO.initializeDatabase(this)
            created = true
        }.start()
        // start main activity
        Thread {
            for(i in 0..80){
                binding.progressBar.progress = i
                Thread.sleep(20)
            }
            while(!created) {
                Thread.sleep(20)
            }
            for(i in 81..100){
                binding.progressBar.progress = i
                Thread.sleep(20)
            }
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }.start()

        // initialize notifications alarm
        val sharedPref = PreferenceManager.getDefaultSharedPreferences(this)
        val notifications = sharedPref.getBoolean("notifications", true)
        if (notifications) {
            Notification.scheduleAlarm(this)
        }
    }
}