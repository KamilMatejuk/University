package com.example.l3z4.tools

import android.content.Context
import androidx.room.*
import com.example.l3z4.R
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

/**
 * Data class containing all informations about each task item
 *
 * @param id number of item on a list
 * @param text description of a task
 * @param creationDate date and time when the task was added
 * @param targetFinishDate date and time that a task should be finished before
 * @param priority how urgent is task
 * @param category what type of task is it
 */
@Entity
data class TodoItem(
    @PrimaryKey var id: Int,
    @ColumnInfo(name = "text") var text: String,
    @ColumnInfo(name = "creation_date") var creationDate: LocalDateTime,
    @ColumnInfo(name = "finish_date") var targetFinishDate: LocalDateTime,
    @ColumnInfo(name = "priority") var priority: Priority,
    @ColumnInfo(name = "category") var category: Category
)

/**
 * Enum containing all possible priorities for task
 *
 * @param text name of priority
 * @param icon number of R.drawable resource with corresponding icon
 * @param color number of R.color resource with corresponding color (same as icon background)
 */
enum class Priority(var text: String, var icon: Int, var color: Int) {
    TRIVIAL("TRIVIAL", R.drawable.priority_01, R.color.priority_01),
    LOwEST("LOWEST", R.drawable.priority_02, R.color.priority_02),
    LOWER("LOWER", R.drawable.priority_03, R.color.priority_03),
    LOW("LOW", R.drawable.priority_04, R.color.priority_04),
    MINOR("MINOR", R.drawable.priority_05, R.color.priority_05),
    HIGH("HIGH", R.drawable.priority_06, R.color.priority_06),
    HIGHER("HIGHER", R.drawable.priority_07, R.color.priority_07),
    HIGHEST("HIGHEST", R.drawable.priority_08, R.color.priority_08),
    CRITICAL("CRITICAL", R.drawable.priority_09, R.color.priority_09);

    override fun toString(): String {
        return text
    }
}

/**
 * Enum containing all possible categories for task
 *
 * @param text name of category
 * @param icon number of R.drawable resource with corresponding icon
 * @param color number of R.color resource with corresponding color (same as icon background)
 */
enum class Category(var text: String, var icon: Int, var color: Int) {
    LOVE("LOVE", R.drawable.category_01, R.color.category_01),
    HOME("HOME", R.drawable.category_02, R.color.category_02),
    SHOPPING("SHOPPING", R.drawable.category_03, R.color.category_03),
    SPORT("SPORT", R.drawable.category_04, R.color.category_04),
    HEALTH("HEALTH", R.drawable.category_05, R.color.category_05),
    COOKING("COOKING", R.drawable.category_06, R.color.category_06),
    MONEY("MONEY", R.drawable.category_07, R.color.category_07),
    GAMING("GAMING", R.drawable.category_08, R.color.category_08),
    PARTY("PARTY", R.drawable.category_09, R.color.category_09),
    TRANSPORT("TRANSPORT", R.drawable.category_10, R.color.category_10),
    ARTISTIC("ARTISTIC", R.drawable.category_11, R.color.category_11),
    THINKING("THINKING", R.drawable.category_12, R.color.category_12),
    NATURE("NATURE", R.drawable.category_13, R.color.category_13),
    OTHER("OTHER", R.drawable.category_14, R.color.category_14);

    override fun toString(): String {
        return text
    }
}

/**
 * Database access object with defined queries
 */
@Dao
interface TodoItemDAO {
    @Query("SELECT * FROM todoitem")
    fun getAll(): List<TodoItem>

    @Insert
    fun insert(item: TodoItem)

    @Delete
    fun delete(item: TodoItem)
}

/**
 * Datbase storing all tasks
 */
@Database(entities = [TodoItem::class], version = 1)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun todoItemDao(): TodoItemDAO
}

/**
 * Converters used to store LocalDateTime, Priority and Category
 */
object Converters {
    /** String -> LocalDateTime */
    @TypeConverter
    @JvmStatic
    fun toDate(dateString: String?): LocalDateTime? {
        return if (dateString == null) {
            null
        } else {
            LocalDateTime.parse(dateString)
        }
    }

    /** LocalDateTime -> String */
    @TypeConverter
    @JvmStatic
    fun toDateString(date: LocalDateTime?): String? {
        return date?.toString()
    }

    /** String -> Priority */
    @TypeConverter
    @JvmStatic
    fun toPriority(priorityString: String?): Priority? {
        if (priorityString != null) {
            for(p in Priority.values()){
                if (p.toString() == priorityString) {
                    return p
                }
            }
        }
        return null
    }

    /** Priority -> String */
    @TypeConverter
    @JvmStatic
    fun toPriorityString(priority: Priority?): String? {
        return priority?.toString()
    }

    /** String -> Category */
    @TypeConverter
    @JvmStatic
    fun toCategory(CategoryString: String?): Category? {
        if (CategoryString != null) {
            for(c in Category.values()){
                if (c.toString() == CategoryString) {
                    return c
                }
            }
        }
        return null
    }

    /** Category -> String */
    @TypeConverter
    @JvmStatic
    fun toCategoryString(Category: Category?): String? {
        return Category?.toString()
    }
}


/**
 * Singleton object used for connection, between app and database
 */
object DataIO {
    private lateinit var itemList: ArrayList<TodoItem>
    private lateinit var db: TodoItemDAO

    /**
     * Create database instance at the beginning of app lifecycle
     */
    fun initializeDatabase(context: Context) {
        db = Room.databaseBuilder(
            context,
            AppDatabase::class.java, "todo-app-database"
        ).build().todoItemDao()
        this.itemList = db.getAll() as ArrayList<TodoItem>
    }

    /**
     * Getters
     */
    fun getTodoList(): List<TodoItem> {
        return itemList.reversed()
    }
    fun getFinishing(): List<TodoItem> {
        return if (this::itemList.isInitialized) {
            val finishing = arrayListOf<TodoItem>()
            val now = LocalDateTime.now()
            for (v in this.itemList) {
                val diff = now.until(v.targetFinishDate, ChronoUnit.MINUTES)
                if (diff < 5) {
                    finishing.add(v)
                }
            }
            return finishing
        } else {
            emptyList()
        }
    }

    /**
     * Sorting functions
     */
    fun sortByPriority() {
        itemList.sortWith(compareBy { it.priority })
    }

    fun sortByCategory() {
        itemList.sortWith(compareBy { it.category })
    }

    fun sortByCreationDate() {
        itemList.sortWith(compareBy { it.creationDate })
    }

    fun sortByFinishDate() {
        itemList.sortWith(compareBy { it.targetFinishDate })
    }

    fun reverse() {
        itemList.reverse()
    }


    /**
     * Operations on values
     */
    fun removeAt(index: Int) {
        println(itemList.size)
        println(index)
        val i = itemList.size - index - 1
        val item = this.itemList[i]
        itemList.removeAt(i)
        this.db.delete(item)
    }

    fun add(text: String, targetFinishDate: LocalDateTime, priority: Priority, category: Category) {
        val item = TodoItem(
            itemList.size,
            text,
            LocalDateTime.now(),
            targetFinishDate,
            priority,
            category
        )
        itemList.add(item)
        this.db.insert(item)
    }

    fun edit(
        index: Int,
        text: String,
        targetFinishDate: LocalDateTime,
        priority: Priority,
        category: Category
    ) {
        val i = itemList.size - index - 1
        this.db.delete(itemList[i])
        itemList[i].text = text
        itemList[i].targetFinishDate = targetFinishDate
        itemList[i].priority = priority
        itemList[i].category = category
        this.db.insert(itemList[i])
    }
}