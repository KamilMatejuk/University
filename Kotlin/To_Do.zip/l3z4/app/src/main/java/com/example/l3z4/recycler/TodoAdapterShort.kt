package com.example.l3z4.recycler

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.l3z4.popups.PopupInfoActivity
import com.example.l3z4.tools.TodoItem
import com.example.l3z4.databinding.TodoItemShortBinding
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit


class TodoAdapterShort(private val itemList: List<TodoItem>):
    RecyclerView.Adapter<TodoAdapterShort.TodoItemHolder>() {

        // Returns a new ViewHolder
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TodoItemHolder {
            val inflater = LayoutInflater.from(parent.context)
            val binding = TodoItemShortBinding.inflate(inflater)
            return TodoItemHolder(binding, parent.context)
        }

        // Returns size of data list
        override fun getItemCount(): Int {
            return itemList.size
        }

        // Displays data at a certain position
        override fun onBindViewHolder(holder: TodoItemHolder, position: Int) {
            holder.bind(itemList[position])
        }

        // ViewHolder
        inner class TodoItemHolder(private var v: TodoItemShortBinding, private var context: Context) : RecyclerView.ViewHolder(v.root) {
            fun bind(item: TodoItem) {
                with(v){
                    taskText.text = crop(item.text)
                    priority.setImageResource(item.priority.icon)
                    category.setImageResource(item.category.icon)

                    if (item.targetFinishDate.year == LocalDateTime.now().year &&
                        item.targetFinishDate.dayOfYear == LocalDateTime.now().dayOfYear){
                        finishDate.text = DateTimeFormatter.ofPattern("HH:mm").format(item.targetFinishDate)
                    } else {
                        finishDate.text = DateTimeFormatter.ofPattern("dd.MM.yyyy").format(item.targetFinishDate)
                    }

                    root.setOnClickListener {
                        showDetails(item)
                    }
                }
            }

            private fun crop(text: String): String {
                val n = 35
                return if (text.length <= n) {
                    text
                } else {
                    text.substring(0, n) + " ..."
                }
            }

            private fun showDetails(item: TodoItem) {
                val fromDateTime = LocalDateTime.now()
                val toDateTime = item.targetFinishDate
                var tempDateTime = LocalDateTime.from(fromDateTime)
                val years = tempDateTime.until(toDateTime, ChronoUnit.YEARS)
                tempDateTime = tempDateTime.plusYears(years)
                val months = tempDateTime.until(toDateTime, ChronoUnit.MONTHS)
                tempDateTime = tempDateTime.plusMonths(months)
                val days = tempDateTime.until(toDateTime, ChronoUnit.DAYS)
                tempDateTime = tempDateTime.plusDays(days)
                val hours = tempDateTime.until(toDateTime, ChronoUnit.HOURS)
                tempDateTime = tempDateTime.plusHours(hours)
                val minutes = tempDateTime.until(toDateTime, ChronoUnit.MINUTES)
                val time = if (years < 0 || months < 0 || days < 0 || hours < 0 || minutes < 0){
                    "Overdue"
                } else if (years > 0) {
                    "$years years $months months $days days\n$hours hours $minutes minutes"
                } else if (months > 0) {
                    "$months months $days days\n$hours hours $minutes minutes"
                } else if (days > 0) {
                    "$days days $hours hours $minutes minutes"
                } else if (hours > 0) {
                    "$hours hours $minutes minutes"
                } else {
                    "$minutes minutes"
                }

                val intent = Intent(context, PopupInfoActivity::class.java)
                intent.putExtra("EXTRA_TASK_TEXT", item.text)
                intent.putExtra("EXTRA_UNTIL_FINISH", time)
                intent.putExtra("EXTRA_PRIORITY_TEXT", item.priority.toString())
                intent.putExtra("EXTRA_PRIORITY_ICON", item.priority.icon)
                intent.putExtra("EXTRA_PRIORITY_COLOR", item.priority.color)
                intent.putExtra("EXTRA_CATEGORY_TEXT", item.category.toString())
                intent.putExtra("EXTRA_CATEGORY_ICON", item.category.icon)
                intent.putExtra("EXTRA_CATEGORY_COLOR", item.category.color)
                ContextCompat.startActivity(context, intent, null)
            }
        }
}