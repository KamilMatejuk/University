package com.example.l3z4

import android.app.Activity
import android.content.Intent
import android.icu.util.Calendar
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.l3z4.popups.PopupCategoryActivity
import com.example.l3z4.popups.PopupPriorityActivity
import com.example.l3z4.tools.Category
import com.example.l3z4.tools.DataIO
import com.example.l3z4.tools.Priority
import com.example.l3z4.tools.Theme
import com.example.l3z4.databinding.ActivityDetailsBinding
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog
import java.time.LocalDateTime


class DetailsActivity : AppCompatActivity(), DatePickerDialog.OnDateSetListener,
    TimePickerDialog.OnTimeSetListener {
    private lateinit var binding: ActivityDetailsBinding
    private var priorityCode = 69
    private var categoryCode = 420
    private var newTask: Boolean = true

    private var chosenText: String = "ToDo"
    private var chosenYear: Int = LocalDateTime.now().year
    private var chosenMonth: Int = LocalDateTime.now().monthValue
    private var chosenDay: Int = LocalDateTime.now().dayOfMonth
    private var chosenHour: Int = LocalDateTime.now().hour
    private var chosenMinute: Int = LocalDateTime.now().minute
    private var chosenPriority: Priority = Priority.TRIVIAL
    private var chosenCategory: Category = Category.OTHER

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // set theme
        Theme.setTheme(this, R.style.Theme_L3z1_Dark, R.style.Theme_L3z1_Light)

        binding = ActivityDetailsBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // check if creating a new task, or editing existing
        newTask = intent.getBooleanExtra("EXTRA_NEW_TASK", true)
        if (!newTask) {
            val taskId = intent.getIntExtra("EXTRA_TASK_ID", 0)
            val task = DataIO.getTodoList()[taskId]
            chosenText = task.text
            chosenYear = task.targetFinishDate.year
            chosenMonth = task.targetFinishDate.monthValue
            chosenDay = task.targetFinishDate.dayOfMonth
            chosenHour = task.targetFinishDate.hour
            chosenMinute = task.targetFinishDate.minute
            chosenPriority = task.priority
            chosenCategory = task.category
        }
        updateData()
    }

    /**
     * Show choosen data
     */
    private fun updateData() {
        binding.textEt.setText(chosenText)
        "${twoDigits(chosenDay)}.${twoDigits(chosenMonth)}.${chosenYear}".also { binding.finishDate.text = it }
        "${twoDigits(chosenHour)}:${twoDigits(chosenMinute)}".also { binding.finishTime.text = it }
        "$chosenPriority".also { binding.priority.text = it }
        "$chosenCategory".also { binding.category.text = it }
        binding.priority.setTextColor(
            ContextCompat.getColor(
                this,
                chosenPriority.color
            )
        )
        binding.category.setTextColor(
            ContextCompat.getColor(
                this,
                chosenCategory.color
            )
        )
    }

    /**
     * Return string from int as at least 2 digits
     */
    private fun twoDigits(n: Int): String {
        return if (n < 10) {
            "0$n"
        } else {
            n.toString()
        }
    }

    /**
     * popup for getting date,
     * using https://github.com/wdullaer/MaterialDateTimePicker
     */
    fun editDate(view: View) {
        val now: Calendar = Calendar.getInstance()
        val dpd: DatePickerDialog = DatePickerDialog.newInstance(
            this@DetailsActivity,
            now.get(Calendar.YEAR),
            now.get(Calendar.MONTH),
            now.get(Calendar.DAY_OF_MONTH)
        )
        dpd.show(supportFragmentManager, "Datepickerdialog");
    }
    override fun onDateSet(view: DatePickerDialog?, year: Int, monthOfYear: Int, dayOfMonth: Int) {
        chosenYear = year
        chosenMonth = monthOfYear + 1
        chosenDay = dayOfMonth
        updateData()
    }

    /**
     * popup for getting time,
     * using https://github.com/wdullaer/MaterialDateTimePicker
     */
    fun editTime(view: View) {
        val now: Calendar = Calendar.getInstance()
        val dpd: TimePickerDialog = TimePickerDialog.newInstance(
            this@DetailsActivity,
            now.get(Calendar.HOUR_OF_DAY),
            now.get(Calendar.MINUTE),
            true
        )
        dpd.show(supportFragmentManager, "Timepickerdialog");
    }
    override fun onTimeSet(view: TimePickerDialog?, hourOfDay: Int, minute: Int, second: Int) {
        chosenHour = hourOfDay
        chosenMinute = minute
        updateData()
    }

    /**
     * popup for getting priority
     */
    fun editPriority(view: View) {
        val intent = Intent(this, PopupPriorityActivity::class.java)
        startActivityForResult(intent, priorityCode)
    }

    /**
     * popup for getting category
     */
    fun editCategory(view: View) {
        val intent = Intent(this, PopupCategoryActivity::class.java)
        startActivityForResult(intent, categoryCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, intentData: Intent?) {
        super.onActivityResult(requestCode, resultCode, intentData)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == priorityCode) {
                val id = intentData?.getIntExtra("EXTRA_ID", 0)
                chosenPriority = Priority.values()[id!!]
            } else if (requestCode == categoryCode) {
                val id = intentData?.getIntExtra("EXTRA_ID", 0)
                chosenCategory = Category.values()[id!!]
            }
            updateData()
        }
    }

    /**
     * Save data and exit
     */
    fun save(view: View?) {
        val text = binding.textEt.text.toString()
        val date = LocalDateTime.of(chosenYear, chosenMonth, chosenDay, chosenHour, chosenMinute)
        if (newTask) {
            Thread { DataIO.add(text, date, chosenPriority, chosenCategory) }.start()
        } else {
            val taskId = intent.getIntExtra("EXTRA_TASK_ID", 0)
            Thread { DataIO.edit(taskId, text, date, chosenPriority, chosenCategory) }.start()
        }
        finish()
    }
    override fun onBackPressed() {
        save(null)
        super.onBackPressed()
    }
}