package com.example.l3z4.tools

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.l3z4.LoadingActivity
import com.example.l3z4.R

/**
 * Class responsible for notifying user
 */
object Notification {
    private var notificationId: Int = 0
    private const val channelId = "CHANNEL_ID"
    private const val name = "CHANNEL_NAME"
    private const val descriptionText = "CHANNEL_DESCRIPTION"

    init {
        notificationId = 0
    }

    /**
    Create one channel for all notifications
     */
    private fun createNotificationChannel(context: Context) {
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel(channelId, name, importance).apply {
            description = descriptionText
        }
        val notificationManager: NotificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    /**
     * Push notifications to the channel
     */
    fun addNotification(context: Context, title: String, text: String) {
        createNotificationChannel(context)

        val intent = Intent(context, LoadingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, 0)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.icon)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText(text)
            )
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        with(NotificationManagerCompat.from(context)) {
            // notificationId is a unique int for each notification that you must define
            notify(notificationId, builder.build())
        }
        notificationId++
    }

    /**
     * Start recurring timer for 5 minutes
     */
    fun scheduleAlarm(context: Context) {
        val intent = Intent(context, MyAlarmReceiver::class.java)
        val pIntent = PendingIntent.getBroadcast(
            context, MyAlarmReceiver.REQUEST_CODE,
            intent, PendingIntent.FLAG_UPDATE_CURRENT
        )
        val firstMillis = System.currentTimeMillis() // alarm is set right away
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setRepeating(
            AlarmManager.RTC_WAKEUP, firstMillis,
            300000, // 5 minutes
            pIntent
        )
    }

    /**
     * Stop recurring timer
     */
    fun cancelAlarm(context: Context) {
        val intent = Intent(context, MyAlarmReceiver::class.java)
        val pIntent = PendingIntent.getBroadcast(
            context, MyAlarmReceiver.REQUEST_CODE,
            intent, PendingIntent.FLAG_UPDATE_CURRENT
        )
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pIntent)
    }
}


/**
 * Receive alarm and show notification
 */
class MyAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        for(i in DataIO.getFinishing()){
            Notification.addNotification(
                context,
                "Deadline is near",
                "Your task '${i.text}' should be finished soon"
            )
        }
    }
    companion object {
        const val REQUEST_CODE = 12345
        // const val ACTION = "com.codepath.example.servicesdemo.alarm"
    }
}