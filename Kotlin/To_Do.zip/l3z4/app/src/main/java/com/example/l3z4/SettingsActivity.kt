package com.example.l3z4

import android.content.SharedPreferences
import android.content.SharedPreferences.OnSharedPreferenceChangeListener
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.PreferenceManager
import com.example.l3z4.tools.Notification
import com.example.l3z4.tools.Theme


class SettingsActivity : AppCompatActivity() {
    private var listener: OnSharedPreferenceChangeListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // set theme
        Theme.setTheme(this, R.style.Theme_L3z1_Dark, R.style.Theme_L3z1_Light)

        setContentView(R.layout.activity_settings)

        if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.settings, SettingsFragment())
                .commit()
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val prefs = PreferenceManager.getDefaultSharedPreferences(this);
        listener = OnSharedPreferenceChangeListener { sharedPreferences: SharedPreferences, key: String ->
            if (key == "notifications") {
                val notifications = sharedPreferences.getBoolean("notifications", false)
                if (notifications) {
                    Notification.scheduleAlarm(this)
                    Notification.addNotification(
                        this,
                        "Example notification",
                        "This is how you will get notifications about approaching tasks"
                    )
                } else {
                    Notification.cancelAlarm(this)
                }
            }
            else if (key == "dark_theme") {
                val dark = sharedPreferences.getBoolean("dark_theme", true)
                if (dark) {
                    setTheme(R.style.Theme_L3z1_Dark)
                } else {
                    setTheme(R.style.Theme_L3z1_Dark)
                }
                recreate()
            }
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                super.onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey)
        }
    }
}
