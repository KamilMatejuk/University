package com.example.l3z4.popups

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.l3z4.tools.Priority
import com.example.l3z4.R
import com.example.l3z4.tools.Theme
import com.example.l3z4.databinding.PopupPriorityActivityBinding


class PopupPriorityActivity : AppCompatActivity() {
    private lateinit var binding: PopupPriorityActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // set theme
        Theme.setTheme(
            this,
            R.style.Theme_L3z1_Dark_Transparent,
            R.style.Theme_L3z1_Light_Transparent
        )

        binding = PopupPriorityActivityBinding.inflate(layoutInflater)
        val view = binding.root
        overridePendingTransition(0, 0)
        setContentView(view)

        // set progress bar width
        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        val height = displayMetrics.heightPixels
        binding.cardView.layoutParams.height = (height * 0.7).toInt()

        addOptions()
    }

    private fun addOptions() {
        val parent = binding.priorityLayout
        val values = Priority.values()
        for (v in values) {
            val layout = LinearLayout(this)
            layout.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, // width
                LinearLayout.LayoutParams.WRAP_CONTENT // height
            )
            layout.orientation = LinearLayout.HORIZONTAL
            val icon = ImageView(this)
            icon.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, // width
                LinearLayout.LayoutParams.WRAP_CONTENT // height
            )
            val text = TextView(this)
            text.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, // width
                LinearLayout.LayoutParams.MATCH_PARENT // height
            )
            text.gravity = Gravity.CENTER_VERTICAL
            text.setPadding(40, 0, 0, 0)
            layout.setPadding(0, 0, 100, 20)
            layout.tag = values.indexOf(v)
            icon.setImageResource(v.icon)
            text.text = v.text
            text.setTextColor(ContextCompat.getColor(this, v.color))
            text.setTypeface(text.typeface, Typeface.BOLD);
            layout.setOnClickListener { view: View? ->
                val returnIntent = Intent()
                returnIntent.putExtra("EXTRA_ID", view?.tag as Int)
                setResult(Activity.RESULT_OK, returnIntent);
                finish()
            }
            layout.addView(icon)
            layout.addView(text)
            parent.addView(layout)
        }
    }
}