package com.example.l3z4

import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.l3z4.databinding.ActivityMainBinding
import com.example.l3z4.recycler.TodoAdapterLong
import com.example.l3z4.recycler.TodoAdapterShort
import com.example.l3z4.tools.DataIO
import com.example.l3z4.tools.Theme

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private var showDetails: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // set theme
        Theme.setTheme(this, R.style.Theme_L3z1_Dark_NoActionBar, R.style.Theme_L3z1_Light_NoActionBar)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        setSupportActionBar(findViewById(R.id.toolbar))

        // get shared prefs
        val prefs = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        showDetails = prefs.getBoolean("details", true)

        // initializes recyclerview with items
        binding.todoRecyclerView.layoutManager = LinearLayoutManager(applicationContext)
        if (showDetails) {
            binding.todoRecyclerView.adapter = TodoAdapterLong(DataIO.getTodoList())
        } else {
            binding.todoRecyclerView.adapter = TodoAdapterShort(DataIO.getTodoList())
        }

        // initializes 'add item' listener
        binding.addBtn.setOnClickListener {
            addOnClick()
        }

        // adding left swipe listener
        addSwipeListener(
            ItemTouchHelper.LEFT, Color.parseColor("#77ff0000"), R.drawable.ic_baseline_delete_24
        ) { v: RecyclerView.ViewHolder ->
            val i = v.adapterPosition
            Thread {
                DataIO.removeAt(i)
                if (showDetails) {
                    binding.todoRecyclerView.adapter = TodoAdapterLong(DataIO.getTodoList())
                } else {
                    binding.todoRecyclerView.adapter = TodoAdapterShort(DataIO.getTodoList())
                }
            }.start()
            binding.todoRecyclerView.adapter?.notifyItemRemoved(i)
            true
        }
        // adding right swipe listener
        addSwipeListener(
            ItemTouchHelper.RIGHT, Color.parseColor("#7700ff00"), R.drawable.ic_baseline_edit_24
        ){ v: RecyclerView.ViewHolder ->
            val intent = Intent(this, DetailsActivity::class.java)
            intent.putExtra("EXTRA_NEW_TASK", false)
            intent.putExtra("EXTRA_TASK_ID", v.adapterPosition)
            startActivityForResult(intent, 0)
            true
        }
    }


    /**
     * Sorting tasks
     */
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivityForResult(intent, 0)
                true
            }
            R.id.sort_1 -> {
                DataIO.sortByCreationDate()
                DataIO.reverse()
                reload()
                true
            }
            R.id.sort_2 -> {
                DataIO.sortByCreationDate()
                reload()
                true
            }
            R.id.sort_3 -> {
                DataIO.sortByFinishDate()
                DataIO.reverse()
                reload()
                true
            }
            R.id.sort_4 -> {
                DataIO.sortByFinishDate()
                reload()
                true
            }
            R.id.sort_5 -> {
                DataIO.sortByPriority()
                DataIO.reverse()
                reload()
                true
            }
            R.id.sort_6 -> {
                DataIO.sortByPriority()
                reload()
                true
            }
            R.id.sort_7 -> {
                DataIO.sortByCategory()
                DataIO.reverse()
                reload()
                true
            }
            R.id.sort_8 -> {
                DataIO.sortByCategory()
                reload()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    fun reload() {
        binding.todoRecyclerView.layoutManager = LinearLayoutManager(applicationContext)
        if (showDetails) {
            binding.todoRecyclerView.adapter = TodoAdapterLong(DataIO.getTodoList())
        } else {
            binding.todoRecyclerView.adapter = TodoAdapterShort(DataIO.getTodoList())
        }
    }

    /**
     * Adding new task
     */
    private fun addOnClick() {
        val intent = Intent(this, DetailsActivity::class.java)
        intent.putExtra("EXTRA_NEW_TASK", true);
        startActivityForResult(intent, 0)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, intentData: Intent?) {
        super.onActivityResult(requestCode, resultCode, intentData)
        // reload
        recreate()
    }

    /**
     * Adding listener for swipe left and right
     */
    fun addSwipeListener(
        direction: Int,
        color: Int,
        drawableIcon: Int,
        onswiped: (RecyclerView.ViewHolder) -> Boolean
    ) {
        val myCallback = object: ItemTouchHelper.SimpleCallback(
            0,
            direction
        ) {

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                onswiped(viewHolder)
            }

            override fun onChildDraw(
                c: Canvas,
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                dX: Float,
                dY: Float,
                actionState: Int,
                isCurrentlyActive: Boolean
            ) {
                val icon = ResourcesCompat.getDrawable(
                    resources!!,
                    drawableIcon,
                    null
                )

                if (direction == ItemTouchHelper.LEFT){
                    c.clipRect(
                        viewHolder.itemView.right.toFloat(),
                        viewHolder.itemView.top.toFloat(),
                        viewHolder.itemView.right.toFloat() + dX,
                        viewHolder.itemView.bottom.toFloat()
                    )
                    c.drawColor(color)
                    val dy = (viewHolder.itemView.height - icon!!.intrinsicHeight) / 2
                    icon.bounds = Rect(
                        viewHolder.itemView.right - icon.intrinsicWidth - dy,
                        viewHolder.itemView.top + dy,
                        viewHolder.itemView.right - dy,
                        viewHolder.itemView.top + icon.intrinsicHeight + dy
                    )
                } else {
                    c.clipRect(
                        0f,
                        viewHolder.itemView.top.toFloat(),
                        dX,
                        viewHolder.itemView.bottom.toFloat()
                    )
                    c.drawColor(color)
                    val dy = (viewHolder.itemView.height - icon!!.intrinsicHeight) / 2
                    icon.bounds = Rect(
                        dy,
                        viewHolder.itemView.top + dy,
                        icon.intrinsicWidth + dy,
                        viewHolder.itemView.top + icon.intrinsicHeight + dy
                    )
                }

                icon.draw(c)
                super.onChildDraw(
                    c, recyclerView, viewHolder,
                    dX, dY, actionState, isCurrentlyActive
                )
            }
        }

        ItemTouchHelper(myCallback).attachToRecyclerView(binding.todoRecyclerView)
    }
}