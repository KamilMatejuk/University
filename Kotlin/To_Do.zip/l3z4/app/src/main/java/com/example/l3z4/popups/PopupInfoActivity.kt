package com.example.l3z4.popups

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.l3z4.R
import com.example.l3z4.tools.Theme
import com.example.l3z4.databinding.PopupInfoActivityBinding

class PopupInfoActivity : AppCompatActivity() {
    private lateinit var binding: PopupInfoActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // set theme
        Theme.setTheme(
            this,
            R.style.Theme_L3z1_Dark_Transparent,
            R.style.Theme_L3z1_Light_Transparent
        )

        binding = PopupInfoActivityBinding.inflate(layoutInflater)
        val view = binding.root
        overridePendingTransition(0, 0)
        setContentView(view)

        // get data
        val bundle = intent.extras
        val taskText = bundle?.getString("EXTRA_TASK_TEXT", "") ?: ""
        val untilFinish = bundle?.getString("EXTRA_UNTIL_FINISH", "") ?: ""
        val priorityText = bundle?.getString("EXTRA_PRIORITY_TEXT", "") ?: ""
        val priorityIcon = bundle?.getInt("EXTRA_PRIORITY_ICON", 0) ?: 0
        val priorityColor = bundle?.getInt("EXTRA_PRIORITY_COLOR", 0) ?: 0
        val categoryText = bundle?.getString("EXTRA_CATEGORY_TEXT", "") ?: ""
        val categoryIcon = bundle?.getInt("EXTRA_CATEGORY_ICON", 0) ?: 0
        val categoryColor = bundle?.getInt("EXTRA_CATEGORY_COLOR", 0) ?: 0

        // show data
        binding.taskText.text = taskText
        binding.untilFinish.text = untilFinish
        binding.priority.setImageResource(priorityIcon)
        binding.priorityText.text = priorityText
        binding.priorityText.setTextColor(ContextCompat.getColor(this, priorityColor))
        binding.category.setImageResource(categoryIcon)
        binding.categoryText.text = categoryText
        binding.categoryText.setTextColor(ContextCompat.getColor(this, categoryColor))

        binding.background.setOnClickListener {
            onBackPressed()
        }
    }
}