package com.example.l3z4.tools

import android.content.Context
import androidx.preference.PreferenceManager

/**
 * Class responsible for setting correct theme,
 * run in each onCreate()
 */
object Theme {
    fun setTheme(context: Context, dark: Int, light: Int) {
        // set theme
        val sharedPref = PreferenceManager.getDefaultSharedPreferences(context)
        val darkTheme = sharedPref.getBoolean("dark_theme", true)
        if (darkTheme)
            context.setTheme(dark)
        else
            context.setTheme(light)
    }
}