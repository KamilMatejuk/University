package com.example.l2z2

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.ContextThemeWrapper
import android.view.View
import android.widget.Button
import android.widget.TableRow
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import com.example.l2z2.databinding.ActivityMainBinding
import java.util.*


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var choosenWord: String
    private var incorrectGuesses = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val letters = arrayOf(
                arrayOf("A", "B", "C", "D", "E", "F", "G", "H", "I"),
                arrayOf("J", "K", "L", "M", "N", "O", "P", "Q", "R"),
                arrayOf("S", "T", "U", "V", "W", "X", "Y", "Z"))
        createKeyboard(letters)
        loadWord()
    }

    private fun createKeyboard(letters: Array<Array<String>>){
        for (row in letters){
            // create table row
            val tableRow = TableRow(this)
            tableRow.layoutParams = TableRow.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT, // width
                    TableRow.LayoutParams.WRAP_CONTENT // height
            )

            for (letter in row){
                // create letter button
                val btn = Button(ContextThemeWrapper(this, R.style.CustomButton), null, 0)
                btn.layoutParams = TableRow.LayoutParams(
                        TableRow.LayoutParams.WRAP_CONTENT, // width
                        TableRow.LayoutParams.WRAP_CONTENT, // height
                        1.0F // weight
                )
                btn.text = letter
                tableRow.addView(btn)
            }
            binding.keyboard.addView(tableRow)
        }
    }

    private fun loadWord(){
        val word = resources.getStringArray(R.array.words).random()
        binding.word.text = "_".repeat(word.length)
        choosenWord = word
        println(word)
    }

    fun choose(view: View){
        view as Button
        val letter = view.text.toString().toLowerCase(Locale.getDefault()).first()
        val guesses = binding.word.text.toString().toLowerCase(Locale.getDefault()).toCharArray()
        val correct = choosenWord.toLowerCase(Locale.getDefault()).toCharArray()
        var guessedCorrect = false
        correct.forEachIndexed{ i, l ->
            if (l == letter){
                guesses[i] = l
                guessedCorrect = true
            }
        }
        if (guessedCorrect){
            binding.word.text = String(guesses).toUpperCase(Locale.ROOT)
            if (guesses.contentEquals(correct)){
                Toast.makeText(this, "Congratulations", Toast.LENGTH_SHORT).show()
                switchAllButtons(false)
            }
        } else {
            incorrect()
        }
        view.isEnabled = false
        ViewCompat.setBackgroundTintList(view,
                ColorStateList.valueOf(ContextCompat.getColor(this, R.color.btn_inactive)))

    }

    fun reload(view: View){
        incorrectGuesses = 0
        loadWord()
        switchAllButtons(true)
        binding.imageView.setImageResource(R.drawable.hangman_00)
    }

    private fun switchAllButtons(state: Boolean){
        val layout = binding.keyboard
        for (i in 0 until layout.childCount) {
            val row = layout.getChildAt(i) as TableRow
            for (j in 0 until row.childCount) {
                val btn = row.getChildAt(j) as Button
                btn.isEnabled = state
                val color = if (state) R.color.btn_active else R.color.btn_inactive

                ViewCompat.setBackgroundTintList(btn,
                        ColorStateList.valueOf(ContextCompat.getColor(this, color)))
            }
        }
    }

    private fun incorrect(){
        incorrectGuesses++
        val name: String
        if (incorrectGuesses < 10) {
            name = "@drawable/hangman_0$incorrectGuesses"
        } else {
            name = "@drawable/hangman_$incorrectGuesses"
            Toast.makeText(this, "You lose, the correct word was $choosenWord", Toast.LENGTH_LONG).show()
            switchAllButtons(false)
        }
        val imageResource = resources.getIdentifier(name, null, packageName)
//        val res = resources.getDrawable(imageResource)
        val res = ContextCompat.getDrawable(this, imageResource)
        binding.imageView.setImageDrawable(res)
    }
}