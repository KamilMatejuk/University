package com.example.l6z2

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.transition.Slide
import android.transition.TransitionManager
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import java.lang.Math.round
import kotlin.math.roundToInt


class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var database: DatabaseReference
    private lateinit var allCities: ArrayList<City>
    private lateinit var spinner: Spinner
    private var popupWindow: PopupWindow? = null
    private var map: GoogleMap? = null
    private var drawingLine: Boolean = false
    private var lineToDrawArray: ArrayList<LatLng> = arrayListOf()
    private var lineToDraw: Polyline? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        database = Firebase.database.reference
        spinner = findViewById(R.id.cities_spinner)
        allCities = arrayListOf()

        // read cities from firebase
        database.child("cities").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                /**
                 * get all messages
                 */
                allCities = arrayListOf()
                dataSnapshot.children.forEach { child ->
                    try {
                        val city: City? = child.getValue(City::class.java)
                        if (city != null) {
                            allCities.add(city)
                        }
                    } catch (e: ClassCastException) {
                        Log.w("Firebase/Database", "Couldn't cast ${child.value} into message")
                    }
                }
                /**
                 * update data in spinner
                 */
                ArrayAdapter(
                    applicationContext,
                    android.R.layout.simple_spinner_item,
                    allCities.map { c -> c.name }
                ).also { adapter ->
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    spinner.adapter = adapter
                    spinner.setSelection(allCities.size - 1)
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(
                    applicationContext, "Failed to load list of cities",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        // set on change listener
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>?,
                selectedItemView: View,
                position: Int,
                id: Long
            ) {
                val city = allCities[position]
                println("selected city $city")
                if (map != null) {
                    val pos = LatLng(city.lat, city.lng)
                    map?.animateCamera(
                        CameraUpdateFactory.newCameraPosition(
                            CameraPosition
                                .Builder()
                                .target(pos)
                                .build()
                        )
                    )
                    map?.moveCamera(
                        CameraUpdateFactory
                            .newLatLngZoom(
                                pos,
                                6.0f
                            )
                    )
                    map?.addMarker(
                        MarkerOptions()
                            .position(pos)
                            .title(city.name)
                    )
                }
            }

            override fun onNothingSelected(parentView: AdapterView<*>?) {}
        }

        // set up map
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // on click listener
        findViewById<ConstraintLayout>(R.id.root_layout).setOnClickListener {
            popupWindow?.dismiss()
        }
    }

    override fun onBackPressed() {
        if (popupWindow != null) {
            popupWindow?.dismiss()
        } else {
            super.onBackPressed()
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        spinner.setSelection(0, true)
        map?.setOnMapClickListener {
            popupWindow?.dismiss()
            if (drawingLine) {
                addToLine(it)
            }
        }
        map?.setOnMarkerClickListener {
            popupWindow?.dismiss()
            if (drawingLine) {
                addToLine(it.position)
            }
            false
        }
        map?.setOnMapLongClickListener {
            // show popup
            showPopupForAddingCity(it)
        }
    }

    fun clearMap(view: View) {
        map?.clear()
        popupWindow?.dismiss()
    }

    fun startDrawingLine(view: View) {
        drawingLine = !drawingLine
        if (drawingLine) {
            view.backgroundTintList = ColorStateList.valueOf(
                resources.getColor(R.color.teal_700)
            )
            changeMapControls(false)
        } else {
            view.backgroundTintList = ColorStateList.valueOf(
                resources.getColor(R.color.teal_200)
            )
            changeMapControls(true)
        }
        lineToDrawArray = arrayListOf()
        lineToDraw?.remove()
        popupWindow?.dismiss()
    }

    private fun changeMapControls(value: Boolean) {
        map?.uiSettings?.isRotateGesturesEnabled = value
        map?.uiSettings?.isScrollGesturesEnabled = value
        map?.uiSettings?.isTiltGesturesEnabled = value
        map?.uiSettings?.isZoomControlsEnabled = value
        map?.uiSettings?.isZoomGesturesEnabled = value
    }

    private fun showPopupForAddingCity(it: LatLng) {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.new_city_opup, null)
        popupWindow?.dismiss()
        popupWindow = PopupWindow(
            view,
            LinearLayout.LayoutParams.MATCH_PARENT, // width
            LinearLayout.LayoutParams.WRAP_CONTENT, // height
            true
        )
        popupWindow?.elevation = 10.0F
        // set animations
        val slideIn = Slide()
        slideIn.slideEdge = Gravity.TOP
        popupWindow?.enterTransition = slideIn
        val slideOut = Slide()
        slideOut.slideEdge = Gravity.BOTTOM
        popupWindow?.exitTransition = slideOut

        // change values
        val tvCoords = view.findViewById<TextView>(R.id.tv_coords)
        val etName = view.findViewById<TextView>(R.id.et_name)
        val btnSave = view.findViewById<TextView>(R.id.btn_save)
        tvCoords.text = "(${it.latitude.roundToInt()}, ${it.longitude.roundToInt()})"
        btnSave.setOnClickListener {
            popupWindow?.dismiss()
        }

        // close popup
        popupWindow?.setOnDismissListener {
            val name = etName.text.toString().trim()
            if (name.isNotEmpty()) {
                val city = City(name, it.latitude, it.longitude)
                println("Adding city $city")
                val newCityRef = database.child("cities").push()
                newCityRef.setValue(city)
                Toast.makeText(
                    applicationContext,
                    "Added city ${city.name}",
                    Toast.LENGTH_SHORT
                ).show()
            }
            popupWindow = null
        }

        // show the popup window on app
        val rootLayout = findViewById<ConstraintLayout>(R.id.root_layout)
        TransitionManager.beginDelayedTransition(rootLayout)
        popupWindow?.showAtLocation(rootLayout, Gravity.CENTER, 0, 0)
    }

    private fun addToLine(it: LatLng) {
        lineToDraw?.remove()
        lineToDrawArray.add(it)
        lineToDraw = map?.addPolyline(
            PolylineOptions()
                .clickable(false)
                .addAll(lineToDrawArray)
        )
        map?.addMarker(MarkerOptions().position(it))
    }
}