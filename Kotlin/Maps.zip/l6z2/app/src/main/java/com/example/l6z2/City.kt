package com.example.l6z2

data class City(
    val name: String = "",
    val lat: Double = 0.0,
    val lng: Double = 0.0
)