package com.example.l5z2

import android.content.Context
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.l5z2.databinding.MessageItemBinding
import kotlin.random.Random

class MessagesAdapter(
    private val messagesList: List<Message>,
    private var usersMap: Map<String?, Int>
) :
    RecyclerView.Adapter<MessagesAdapter.MessageHolder>() {

    // Returns a new ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = MessageItemBinding.inflate(inflater)
        return MessageHolder(binding, parent.context)
    }

    // Returns size of data list
    override fun getItemCount(): Int {
        return messagesList.size
    }

    // Displays data at a certain position
    override fun onBindViewHolder(holder: MessageHolder, position: Int) {
        holder.bind(messagesList[position])
    }

    // ViewHolder
    inner class MessageHolder(
        private var v: MessageItemBinding,
        private var context: Context
    ) : RecyclerView.ViewHolder(v.root) {
        fun bind(item: Message) {
            println(usersMap)
            with(v) {
                val author = item.author ?: "unknown"
                username.text = "${author.split("@")[0]}:"
                username.setTextColor(usersMap[item.author] ?: Color.WHITE)
                message.text = item.text
            }
        }
    }
}