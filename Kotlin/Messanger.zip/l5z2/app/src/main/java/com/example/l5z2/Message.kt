package com.example.l5z2

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class Message(
    var author: String? = "",
    var text: String? = ""
)
