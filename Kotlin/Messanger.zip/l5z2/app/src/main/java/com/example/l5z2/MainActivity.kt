package com.example.l5z2

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.l5z2.databinding.ActivityLoginBinding
import com.example.l5z2.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private var currentUser: FirebaseUser? = null
    private lateinit var database: DatabaseReference
    private lateinit var binding: ActivityMainBinding
    private var TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        auth = Firebase.auth
        database = Firebase.database.reference
    }

    override fun onStart() {
        super.onStart()
        currentUser = auth.currentUser
        if (currentUser == null) {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        // add change listener
        database.child("messages").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                Log.d(TAG, "Number of messages: ${dataSnapshot.childrenCount}")
                // get all messages
                val messages = arrayListOf<Message>()
                dataSnapshot.children.forEach { child ->
                    try {
                        val message: Message? = child.getValue(Message::class.java)
                        if (message != null) {
                            messages.add(message)
                            Log.d(TAG, "User ${message.author} send '${message.text}'")
                        }
                    } catch (e: ClassCastException) {
                        Log.w(TAG, "Couldn't cast ${child.value} into message")
                    }
                }
                // update recyclerview
                binding.recyclerView.layoutManager = LinearLayoutManager(applicationContext)
                binding.recyclerView.adapter = MessagesAdapter(messages, mapUsersToColors(messages))
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(TAG, "messages:onCancelled", databaseError.toException())
                Toast.makeText(
                    applicationContext, "Failed to load messages.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    fun send(view: View) {
        val mess = binding.message.text.toString()
        if (mess.isNotEmpty() && currentUser != null) {
            val message = Message(currentUser!!.email, mess)
            val newMessageRef = database.child("messages").push()
            newMessageRef.setValue(message)
        }
        binding.message.setText("")
    }

    private fun mapUsersToColors(messagesList: List<Message>): Map<String?, Int> {
        val users = messagesList.map { message -> message.author }.distinct()
        println(users)
        return users.map {
            it to Color.argb(
                255,
                Random.nextInt(256),
                Random.nextInt(256),
                Random.nextInt(256)
            )
        }.toMap()
    }

    fun logout(view: View) {
        FirebaseAuth.getInstance().signOut()
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}