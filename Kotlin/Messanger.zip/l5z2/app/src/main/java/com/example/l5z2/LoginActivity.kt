package com.example.l5z2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.example.l5z2.databinding.ActivityLoginBinding
import com.example.l5z2.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class LoginActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        auth = Firebase.auth
    }

    fun switchRegister(view: View) {
        val intent = Intent(this, RegisterActivity::class.java)
        startActivity(intent)
        finish()
    }

    fun login(view: View) {
        val email = binding.emailEt.text.toString()
        val pass = binding.passwordEt.text.toString()
        if (email.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Fill all data", Toast.LENGTH_SHORT).show()
            return
        }

        auth.signInWithEmailAndPassword(email, pass)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    Log.e(
                        "LoginActivity",
                        "signInWithEmailAndPassword:failure",
                        task.exception)
                    Toast.makeText(this, "Incorrect login / password", Toast.LENGTH_SHORT).show()
                }
            }
    }
}