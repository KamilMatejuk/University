package com.example.l2z1

import android.graphics.Rect
import android.view.*
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import java.lang.Integer.min
import kotlin.random.Random


abstract class PlayActivity: AppCompatActivity() {

    lateinit var board: Array<Array<Int>>
    lateinit var currentPlayer: Players

    abstract fun playerWon(posX: Int, posY: Int): Boolean

    fun scaleButtons(layout: ConstraintLayout, n: Int){
        val metrics = windowManager.currentWindowMetrics
        val bounds: Rect = metrics.bounds
        val size = (0.9 * min(bounds.width(), bounds.height()) / n).toInt()
        println(size)

        for (i in 0 until layout.childCount) {
            val child = layout.getChildAt(i)
            if (child is Button) {
                child.width = size
                child.height = size
                child.textSize = (size / 6).toFloat()
            }
        }

    }

    fun createBoard(dim: Int){
        board = Array(dim) {Array(dim) {0}}
        currentPlayer = if (Random.nextBoolean()) Players.O else Players.X
        Toast.makeText(this, "Starting player: $currentPlayer", Toast.LENGTH_SHORT).show()
    }

    fun move(view: View){
        view as Button
        /// set text
        view.text = currentPlayer.toString()
        // deactiavate btn
        view.isEnabled = false
        // add to board
        var tag = view.tag.toString().toInt() - 1
        var dim = board.size
        var posX = tag % dim
        var posY = (tag / dim).toInt()
        board[posX][posY] = currentPlayer.code
        // check if someone won
        if(playerWon(posX, posY)){
            endPlay(currentPlayer)
        } else if(!freeSpaces()) {
            endPlay(Players.NOBODY)
        } else {
            currentPlayer = currentPlayer.next()
        }
    }

    fun freeSpaces(): Boolean {
        for (row in board){
            for (item in row){
                if (item == 0){
                    return true
                }
            }
        }
        return false
    }

    fun endPlay(winner: Players){
        Toast.makeText(this, "$winner won", Toast.LENGTH_SHORT).show()
        setResult(winner.code)
        finish()
    }

    fun allEqual(vararg items: Int): Boolean {
        var value = items[0]
        for(i in items){
            if(i != value){
                return false
            }
        }
        return true
    }

}