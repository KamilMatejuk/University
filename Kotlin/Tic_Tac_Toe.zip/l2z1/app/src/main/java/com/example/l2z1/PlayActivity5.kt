package com.example.l2z1

import android.os.Bundle
import com.example.l2z1.databinding.ActivityPlay5Binding

class PlayActivity5 : PlayActivity() {
    private lateinit var binding: ActivityPlay5Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlay5Binding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        scaleButtons(view, 5)
        createBoard(5)
    }

    override fun playerWon(posX: Int, posY: Int): Boolean {
        // check row
        if(allEqual(
                board[posX][0],
                board[posX][1],
                board[posX][2],
                board[posX][3],
                board[posX][4])){
            return true
        }
        // check column
        if(allEqual(
                board[0][posY],
                board[1][posY],
                board[2][posY],
                board[3][posY],
                board[4][posY])){
            return true
        }
        // check diagonal
        if(allEqual(
                board[0][0],
                board[1][1],
                board[2][2],
                board[3][3],
                board[4][4],
                currentPlayer.code)){
            return true
        }
        if(allEqual(
                board[0][4],
                board[1][3],
                board[2][2],
                board[3][1],
                board[4][0],
                currentPlayer.code)){
            return true
        }
        // else
        return false
    }
}