package com.example.l2z1;

import org.jetbrains.annotations.NotNull;

public enum Players {
    X("X", 1),
    O("O", 2),
    NOBODY("Nobody", 3);

    private final String name;
    private final int code;

    Players(String name, int code){
        this.name = name;
        this.code = code;
    }

    public int getCode() {
        return this.code;
    }

    @NotNull
    @Override
    public String toString() {
        return name;
    }

    public static Players valueOf(int code) {
        for(Players p: values()){
            if(p.code == code){
                return p;
            }
        }
        return null;
    }

    public Players next() {
        if(this == Players.O){
            return Players.X;
        } else {
            return Players.O;
        }
    }
}
