package com.example.l4z3

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RatingBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class DescriptionFragment : Fragment() {

    private var imageId: Int = -1
    var imageRating: Int = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_description, container, false)
        view.findViewById<RatingBar>(R.id.rating)?.setOnRatingBarChangeListener { ratingBar: RatingBar, fl: Float, b: Boolean ->
            if (b && imageId != -1){
                Thread {
                    DataIO.edit(imageId, fl.toInt())
                }.start()
                imageRating = fl.toInt()
            }
        }
        return view
    }

    fun setData(id: Int, date: LocalDateTime, description: String, rating: Int) {
        imageId = id
        imageRating = rating
        val formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy (HH:mm)")
        view?.findViewById<TextView>(R.id.date)?.text = date.format(formatter)
        view?.findViewById<TextView>(R.id.description)?.text = description
        view?.findViewById<RatingBar>(R.id.rating)?.rating = rating.toFloat()
    }

}