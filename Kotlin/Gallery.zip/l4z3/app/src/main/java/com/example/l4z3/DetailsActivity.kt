package com.example.l4z3

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDateTime


class DetailsActivity : AppCompatActivity() {
    private lateinit var descriptionFragment: DescriptionFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        val id = intent.getIntExtra("EXTRA_IMAGE_ID", -1)
        val path = intent.getStringExtra("EXTRA_IMAGE_PATH")
        val description = intent.getStringExtra("EXTRA_IMAGE_DESC") ?: "None"
        val rating = intent.getIntExtra("EXTRA_IMAGE_RATING", 0)
        val date = intent.getSerializableExtra("EXTRA_IMAGE_DATE") as LocalDateTime

        val imageFragment = supportFragmentManager.findFragmentById(R.id.image_fragment) as ImageFragment
        if (path != null) {
            imageFragment.setData(path)
        }
        descriptionFragment = supportFragmentManager.findFragmentById(R.id.description_fragment) as DescriptionFragment
        descriptionFragment.setData(id, date, description, rating)
    }

    override fun onBackPressed() {
        val data = Intent()
        data.putExtra("EXTRA_RATING", descriptionFragment.imageRating)
        setResult(RESULT_OK, data)
        finish()
    }
}