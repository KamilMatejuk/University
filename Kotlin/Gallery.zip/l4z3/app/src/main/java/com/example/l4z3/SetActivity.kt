package com.example.l4z3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText

class SetActivity : AppCompatActivity() {
    private lateinit var path: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set)

        path = intent.getStringExtra("EXTRA_PATH").toString().replace("file://", "")
    }

    fun save(view: View) {
        val desc = findViewById<EditText>(R.id.description_et).text.toString()
        Thread {
            DataIO.add(path, desc)
        }.start()
        setResult(RESULT_OK)
        finish()
    }
}