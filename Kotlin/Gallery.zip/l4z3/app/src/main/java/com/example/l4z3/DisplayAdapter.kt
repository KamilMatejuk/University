package com.example.l4z3

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File


class DisplayAdapter(private val itemList: List<Image>, private val context: Context) :
    RecyclerView.Adapter<DisplayAdapter.ViewHolder>() {

    // Returns a new ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = if (viewType == 0) {
            inflater.inflate(R.layout.display_item_title, parent, false)
        } else {
            inflater.inflate(R.layout.display_item_image, parent, false)
        }
        return ViewHolder(view, viewType, context)
    }

    override fun getItemViewType(position: Int): Int {
        return if (itemList[position].type == "title") 0 else 1
    }

    // Returns size of data list
    override fun getItemCount(): Int {
        return itemList.size
    }

    // Displays data at a certain position
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(itemList[position])
    }

    // ViewHolder
    inner class ViewHolder(
        private var v: View,
        private var viewType: Int,
        private var context: Context
    ) :
        RecyclerView.ViewHolder(v) {
        fun bind(item: Image) {
            if (viewType == 0) {
                v.findViewById<TextView>(R.id.textView).text = "Images with ${item.rating} stars"
            } else {
                val imgFile = File(item.path)
                if (imgFile.exists()) {
                    val myBitmap = BitmapFactory.decodeFile(imgFile.absolutePath)
                    v.findViewById<ImageView>(R.id.imageView).setImageBitmap(myBitmap)
                }

                v.setOnClickListener {
                    val intent = Intent(context, DetailsActivity::class.java)
                    intent.putExtra("EXTRA_IMAGE_ID", item.id)
                    intent.putExtra("EXTRA_IMAGE_PATH", item.path)
                    intent.putExtra("EXTRA_IMAGE_DESC", item.description)
                    intent.putExtra("EXTRA_IMAGE_RATING", item.rating)
                    intent.putExtra("EXTRA_IMAGE_DATE", item.date)
                    (context as Activity).startActivityForResult(intent, 69)
                }
            }

        }

    }
}